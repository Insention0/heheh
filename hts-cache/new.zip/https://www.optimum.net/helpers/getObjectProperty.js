<!DOCTYPE html>
<html>
  <head>
    		<title>Optimum |  404 </title><script type="text/javascript" src=/assets/hosted/js/optimum-common.js?single></script>
 
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="facebook-domain-verification" content="o9kivbfhh44as689ztfzj03gqr86hi" />
    
        <meta name="description" content="Get online support for your cable, phone and internet services from 
        Optimum. Pay your bill, connect to WiFi, check your email and voicemail, see what's on TV and more!"> 

    <link rel="shortcut icon" type="image/x-icon" href="/favicon.ico">
    <link rel="stylesheet" href="https://assets.sitescdn.net/answers-search-bar/v1.0/answers.css">
    <link rel="stylesheet" href="/core-and-parts_page_1.css?202303201419">
    <link rel="stylesheet" href="/core-and-parts_page_2.css?202303201419">
    <link rel="stylesheet" href="/404/page.css?202303201419">
    <!--[if IE 8]><link rel="stylesheet" href="/assets/css/ie8.css?202303201419"><![endif]-->

    <!--[if lte IE 8]><script src="/ieshiv.js?202303201419"></script><![endif]-->
    <!--[if lte IE 8]><script src="/PIE.js?202303201419"></script><![endif]-->
    <!--[if lte IE 8]><script src="/PIE.htc?202303201419"></script><![endif]-->
    
	<script src="/assets/hosted/js/onetmotionpoint.js"></script>
	<script src="/assets/hosted/js/liveperson.js"></script>
    <script src="https://assets.sitescdn.net/answers-search-bar/v1.0/answerstemplates.compiled.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.11"></script>
    <script src="/modernizr.custom.28587.min.js"></script>
    <script>
    if(!window.console) {
        var console = {
            log : function(){},
            error : function(){},
            warn: function(){},
            info: function(){},
            debug: function(){}
        };
    }
    </script>
<!--[if !IE]> -->
	<script>
    /* jshint ignore:start */
	(function(g, b, d, f) {
		(function(a, c, d) {
			if (a) {
				var e = b.createElement("style");
				e.id = c;
				e.innerHTML = d;
				a.appendChild(e)
			}
		})(b.getElementsByTagName("head")[0], "at-body-style", d);
		setTimeout(function() {
			var a = b.getElementsByTagName("head")[0];
			if (a) {
				var c = b.getElementById("at-body-style");
				c && a.removeChild(c)
			}
		}, f)
	})(window, document, "body {opacity: 0 !important}", 3E3);
  /* jshint ignore:end */
    (function() {
        var scriptUrl;
        if((/www|espanol/).test(window.location.host)) {
            scriptUrl = "//assets.adobedtm.com/5b7063f54823/6d6d655087a2/launch-6b631ac52479.min.js";
        } else {
            scriptUrl = "//assets.adobedtm.com/5b7063f54823/6d6d655087a2/launch-fd078045528e-staging.min.js";
        }
        var scriptTag = document.createElement("script");
        scriptTag.src = scriptUrl;
        document.head.appendChild(scriptTag);
    })();
    </script>
<!-- <![endif]-->  
  </head>
  <!--[if lt IE 7 ]> <body class="ie6" data-ng-app="404" data-ng-controller="404Ctrl"> <![endif]-->
  <!--[if IE 7 ]>    <body class="ie7" data-ng-app="404" data-ng-controller="404Ctrl"> <![endif]-->
  <!--[if IE 8 ]>    <body class="ie8" data-ng-app="404" data-ng-controller="404Ctrl"> <![endif]-->
  <!--[if IE 9 ]>    <body class="ie9" data-ng-app="404" data-ng-controller="404Ctrl"> <![endif]-->
  <!--[if (gt IE 9)|!(IE)]><!--> <body data-ng-app="404" data-ng-controller="404Ctrl"> <!--<![endif]-->
	<!-- Google Tag Manager -->
	<noscript>
		<iframe src="//www.googletagmanager.com/ns.html?id=GTM-MFVCV8"
			height="0" width="0" style="display: none; visibility: hidden"></iframe>
	</noscript>
	<script>
		(function(w, d, s, l, i) {
			w[l] = w[l] || [];
			w[l].push({
				'gtm.start' : new Date().getTime(),
				event : 'gtm.js'
			});
			var f = d.getElementsByTagName(s)[0], j = d.createElement(s), dl = l !== 'dataLayer' ? '&l='+ l: '';
			j.async = true;
			j.src = '//www.googletagmanager.com/gtm.js?id=' + i + dl;
			f.parentNode.insertBefore(j, f);
		})(window, document, 'script', 'dataLayer', 'GTM-MFVCV8');
	</script>
	<!-- End Google Tag Manager -->
	<!--Medallia "always on" survey-->
	<script type="text/javascript" src="https://resources.digital-cloud.medallia.com/wdcus/68497/onsite/embed.js" async>
  	</script>
	<div id="site-wrapper" ng-click="fnCloseMobileFlyOut()" ng-cloak>  <!-- wrapper for entire site, minue mobile flyout menu -->

<div id="header-wrapper" ng-controller="CommonHeaderCtrl" ng-cloak>
<!-- 1st popup
<div modal ng-show="CommonHeaderCtrl.softPavedAccount" class="email-security-modal program modal--responsive">
    <div panel class="padding-l first-popup-content">
    	<header class="mobpanel__header hidden-desktop hidden-tablet">
	        <div class="container">
	          <h2>Email advisory</h2>
	          <button class="btn btn--secondary phone-close" ng-click="CommonHeaderCtrl.showSecondModel()">Close</button>
	        </div>
	      </header>
    	<div class="container">
        	<div class="popup-content1">
                <div class="icon_left"><span class="dot"><span class="dot-inner" ><i ng-show="!model.img" ng-class="model.icon" class="ng-scope icon-warning-sign"></i></span></span></div>
                <div class="popup-text">
                    <h2>Email advisory</h2>
                    <p class="hidden-desktop hidden-tablet">Through routine monitoring, we've identified some unusual activity linked to your Optimum email address.</p>
                    <p class="hidden-desktop hidden-tablet">As a safety precaution, please change your password.</p>
                    <p class="hidden-phone">Through routine monitoring, we've identified some unusual activity linked to the Optimum email address yourid@optimum.net.</p>
                    <p class="hidden-phone">As a safety precaution, we strongly recommend you change your password.</p>
                    <span class="primary cta-arrow-link hidden-desktop hidden-tablet">
                      <a class="font-cta-link"  href=#">
                        <span class="cta-wrap">
                          <div class="cta-dot">
                            <i class="cta-circle icon-arrow-right" ng-class="iconClass"></i>
                          </div>
                        </span>
                      <span class="ng-scope">Learn more</span></a>
                    </span>
                </div>
            </div>
        </div>
        <footer class="panel__footer">
      <div class="container">
      	<div class="row">
      		<div class="span5"><button class="btn btn-dual-primary span10" ng-click="CommonHeaderCtrl.goToChangePass()">Change my password</button></div>
      		<input type="button" class="btn btn-dual-secondary del_margin btn-style bold toggle-width span2" ng-click="CommonHeaderCtrl.showSecondModel()" value="Not now"> </input>
            <span class="primary cta-arrow-link">
              <a class="font-cta-link"  href=#">
                <span class="cta-wrap">
                  <div class="cta-dot">
                    <i class="cta-circle icon-arrow-right" ng-class="iconClass"></i>
                  </div>
                </span>
              <span class="ng-scope">Learn more</span></a>
            </span>
        </div>
        </div>
      </footer>
    </div>
</div> -->

<!-- 2nd popup
<div modal ng-show="CommonHeaderCtrl.secondmodel" class="email-security-modal program modal--responsive mail-blocked">
    <div panel class="padding-l second-popup-content">
    	<header class="mobpanel__header hidden-desktop hidden-tablet">
	        <div class="container">
	          <h2>Please note</h2>
	          <button class="  btn btn--secondary phone-close" ng-click="CommonHeaderCtrl.closeSecondModel()">Close</button>
	        </div>
	      </header>
    	<div class="container">
        	<div class="popup-content1">
                <div class="icon_left"><span class="dot"><span class="dot-inner" ><i ng-show="!model.img" ng-class="model.icon" class="ng-scope icon-envelope-alt"></i></span></span></div>
                <div class="popup-text">
                    <h2>Outgoing mail is restricted</h2>
                    <p class="text1">Please be aware that until your password is changed, email you send from software programs like Outlook and Mac Mail, or from the mail app on your smart phone or tablet, will not be delivered.</p>
                    <p>You'll still receive incoming mail.  And, you can continue to send and receive mail using webmail.</p>
                </div>
            </div>
        </div>
        <footer class="panel__footer">
      <div class="container">
      	<div class="row">
      		<div class="span5"><button class="btn btn-dual-primary span10" ng-click="CommonHeaderCtrl.goToChangePass()">OK, change my password </button></div>
      		<input type="button" class="btn btn-dual-secondary del_margin btn-style bold toggle-width span2"  ng-click="CommonHeaderCtrl.closeSecondModel()" value="Continue"> </input>
        </div>
        </div>
      </footer>
    </div>
</div> -->




<section id="common_header" class="common-header alert-{{CommonHeaderCtrl.currentAlert}}" data-ng-class="{true: 'logged-in', false: 'logged-out'}[CommonHeaderCtrl.currentLoggedInUser.hasSession]">

<!-- PHONE: HEADER -->
<div class="csr-div hidden"> <!--Wrapper div to work-around the issue caused by display:inherit!important given globally-->
<div class="pay-bill-csr hidden-desktop hidden-tablet">
    <span>Currently viewing account details for: <span data-ng-bind-html="currentAccountNumber" class="accno-text"></span></span>
    <input type="button" value="Sign out" class="btn btn--primary padding-btn" data-ng-click="CommonHeaderCtrl.handleUserSignout()" />
</div>
</div>
<!-- ALERT DRAWER -->
  <span id="phoneAlertNotRequired" class="hidden-desktop hidden-tablet" data-ng-show="CommonHeaderCtrl.currentAlertIndex > 0">
    <div drawer open="drawerModel.isOpen">
        <div alert-drawer></div>
    </div>
  </span>

  <div class="visible-phone visible-tablet global-header hideForNewCustomerStuff" id="newLoginCustomerHeader" >
<div class="container">
<div class="semflex full-width align-children-middle">
        <div class="global-header-phone__brand">
            <a href="/" class="block mobile-logo"></a>
         </div>
        </div>
        </div>
        </div>

<div class="visible-phone visible-tablet global-header alert-{{CommonHeaderCtrl.currentAlert}}">
    <div id="phone_header" class="semflex full-width align-children-middle">
        <div class="vpadding-s global-header-phone__brand">
            <a href="/" class="block mobile-logo"></a>
        </div>

        <div class="global-nav-secondary__notification" data-ng-show="CommonHeaderCtrl.currentAlertIndex > 0">

        <a data-ng-click="CommonHeaderCtrl.toggleAlertDrawer()" class="alert-{{CommonHeaderCtrl.currentAlert}}
        alert-drawer__handle hbeam-inline badge-notification badge-primary toggle-alert-mrgin">
            <div class="hbeam-part-static badge-notification__icon-container">
                <i class="badge-notification__icon icon-warning-sign"></i>
            </div>
            <div>
                <span class="badge-notification__count">{{CommonHeaderCtrl.currentAlertIndex}}</span>
            </div>
        </a>
    </div>


        <div class="global-header-phone__nav__item align-center icon-search" data-ng-click="CommonHeaderCtrl.toggleMobileSearchBarDisplay()" id="menusearch"></div>
        <div class="global-header-phone__nav__item align-center icon-align-justify" id="menubutton" data-ng-click="CommonHeaderCtrl.toggleMobileMenuDisplay()"></div>
    </div>
    <!-- PHONE:SEARCH -->
    <div sticky-stack data-ng-show="CommonHeaderCtrl.showingMobileSearchBar" id="phone-search" class="sticky-stack-pseudo auto_complete_display_none">
        <div class="phone-search-bar vpadding-s">
            <div class="container">
                <div class="semflex full-width align-children-middle">
                    <div class="close-search-wrapper align-left">
                        <a class="close-search" data-ng-click="CommonHeaderCtrl.toggleMobileSearchBarDisplay()">
                            <svg viewBox="2 -0 10 14" xmlns="http://www.w3.org/2000/svg" width="35" height="30" style="vertical-align: middle;">
                                <line x1="0" x2="6" y1="8" y2="1" stroke-width="0.8" stroke="#d9d9d9" fill="none"></line>
                                <line x1="0" x2="6" y1="8" y2="14" stroke-width="0.8" stroke="#d9d9d9" fill="none"></line>
                            </svg>
                        </a>
                    </div>
                    <div class="width_90">
                        <div class="yext-search searchbar-group input-groupp"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> <!-- visible phone -->

<!-- DESKTOP/TABLET: HEADER -->
<div style="min-width:1000px" id="desktop_header">
<div sticky-stack class="global-header hidden-phone hidden-tablet sticky-stack-pseudo" id="desktop_header_NewCustomer">
<div class="pay-bill-csr csr-div hidden">
    <span>Currently viewing account details for: <span data-ng-bind="currentAccountNumber" class="accno-text"></span></span>
    <input type="button" value="Sign out" class="btn btn--primary padding-btn" data-ng-click="CommonHeaderCtrl.handleUserSignout()" />
</div>

<div id="alertNotShown" data-ng-show="CommonHeaderCtrl.currentAlertIndex > 0">
    <div drawer open="drawerModel.isOpen">
        <div alert-drawer></div>
    </div>
</div>

<div class="container">
<div class="toggle-container">

<div id="headerNotShown" class="row app-header__row-top clear-float">
<div class="span4 ipad-width-4">

    <!-- DESKTOP/TABLET: TERTIARE NAV -->

    <div class="vpadding-s">

    <div class="speech-bubble-home-wrapper">
    <!--
    <ul class="global-nav-tertiary list-unstyled">
          <li class="global-nav-tertiary__item">
            <a href="#" class="global-header__link">en Espa&#241;ol</a>
          </li>
    </ul>
    -->

<div class="motion-point">
        <a mporgnav href="https://espanol.optimum.net"
                onclick="return switchLanguage('es');
                function switchLanguage(lang) {
                MP.SrcUrl=decodeURIComponent('mp_js_orgin_url');
                MP.UrlLang='mp_js_current_lang';MP.init();
                MP.switchLanguage(MP.UrlLang==lang?'en':lang);
                return false;}">En espa&#241;ol</a>
</div>


            <div class="pull-right speech-bubble-home-container" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession">
                <a href="{{CommonHeaderCtrl.helloMessage.link}}" class="welcome-message speech-balloon speech-balloon--tip-outwards header-user" data-ng-class="{active : CommonHeaderCtrl.currentUserStatus == 'signin'}" data-ng-mouseenter="CommonHeaderCtrl.currentUserStatus='signin'" data-ng-mouseleave="CommonHeaderCtrl.currentUserStatus=''">
                    <div class="speech-balloon__content"><p class="username-msg">{{CommonHeaderCtrl.helloMessage.text}}</p></div>
                    <div class="speech-balloon__tip"></div>
                </a>
            </div>
            <div class="pull-right speech-bubble-home-container" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession">
                <div class="welcome-message speech-balloon speech-balloon--tip-outwards">
                    <div class="speech-balloon__content row">
                        <div class="span5 username-msg-div"><a href="{{CommonHeaderCtrl.helloMessage.link}}" class="username-msg">{{CommonHeaderCtrl.helloMessage.text}}</a></div>
                        <div class="span1 verticalLine"></div>
                        <div class="span5 signout-msg-div"><a data-ng-click="CommonHeaderCtrl.handleUserSignout()" class="signout-msg">Sign out</a></div>
                    </div>
                    <div class="speech-balloon__tip"></div>
                </div>
            </div>
        </div><!--end of speech-bubble-home-wrapper-->
    </div>

</div>


<div class="app-header__secondary-nav span8 ipad-width-8">
<div class="row">
<div class="span12">

<!-- DESKTOP: SECONDARY NAV -->

<div class="global-nav-secondary">

<div class="hbeam-inline global-nav-secondary__item">
    <div class="global-nav-secondary__label">
        <a class="block-link" data-ng-click="CommonHeaderCtrl.handleMenuSelect('profile')" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('profile')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('profile')" class="global-header__link" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('profile')}">
            <span class="show-profilelink">My profile</span>
            <span class="show-signin">Sign in</span>
        </a>

        <div class="header-dropmenu signin-profile" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('profile')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('profile')" data-ng-show="CommonHeaderCtrl.isActiveMenu('profile')" >
            <div class="menu-mdl" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession">

                <!--logged in-->
                <div>
                    <ul>
                        <li><a href="/profile">Personal info</a></li>
                        <li><a href="/profile/#comm-pref">Notification preferences</a></li>
                        <li><a href="/profile/household-ids">My household IDs</a></li>
                        <li><a href="/internet/manage-devices">My wireless devices</a></li>
                        <li data-ng-show="CommonHeaderCtrl.currentLoggedInUser.isPrimary"><a href="/profile/create-secondary-id">Create an Optimum ID</a></li> <!--HIDE this if not Primary/Account holder-->
                        <esi:include src="/services/cms-menu?path=my-profile" />
                    </ul>
                </div>
            </div>
            <div class="menu-top" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession">
                <!--end of logged in-->

                <!--logged out-->
                <div>
                    <h4>Sign in to manage your profile and devices</h4>

                    <form id="signinForm" method="post" ng-submit="CommonHeaderCtrl.handleUserLogin('signinForm')">

                        <div class="row">
                            <div class="span12">
                                <h4>My Optimum ID</h4>
                            </div>
                            <div class="span6">
                                <input type="text" name="id" id="signinFormOptimumId" autocorrect="off" autocapitalize="off"  data-ng-model="CommonHeaderCtrl.userInput.signinForm.optimumId" tabindex="11" value="">
                                <p class="error" data-ng-show="CommonHeaderCtrl.userInput.signinForm.isNotValidOptimumId">Invalid Optimum ID, please complete all fields.</p>
                            </div>
							<br>
                            <div class="span6">
                                <a href="/recover-id" tabindex="14">Forgot my Optimum ID</a>
                            </div>
                        </div>
						<br>
                        <div class="row">
                            <div class="span12">
                                <h4>Password</h4>
                            </div>
                            <div class="span6">
                                <input type="password" id="signinFormPassword" name="password" autocorrect="off" autocapitalize="off" data-ng-model="CommonHeaderCtrl.userInput.signinForm.password" tabindex="12">
                                <p class="error" data-ng-show="CommonHeaderCtrl.userInput.signinForm.isNotValidPassword">Invalid password, please complete all fields.</p>
                            </div>
                            <div class="span6">
                                <a href="/reset-password" tabindex="15">I forgot my password</a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="span12">
                                <hr>
                            </div>
                            <div class="span12">
                                <div class="remember-me-login">
                                    <input class="btn btn--primary" tabindex="13" type="submit" value="Sign in">
                                    <div class="remember-me-group">
                                        <input type="hidden" data-ng-model="CommonHeaderCtrl.userInput.remember_bool" name="remember" value="{{CommonHeaderCtrl.userInput.signinForm.remember_bool}}">
                                        <input type="hidden" name="referer" value="{{CommonHeaderCtrl.loginFormReferer}}">
                                        <span data-ng-click="CommonHeaderCtrl.toggleUserInputRemember('signinForm')">
                                            <input data-ng-model="CommonHeaderCtrl.userInput.signinForm.remember_string" class="checkbox checkbox--secondary remember-checkbox" true-value="yes" tabindex="16">Remember Me
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                </div>
                <!--end of logged out-->


            </div>
            <div class="menu-bottom" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession">

                <!--logged in-->
                <div>
                    <p class="signout-text">Not {{CommonHeaderCtrl.currentLoggedInUser.optimumId}}?</p> <a cta-arrow-link class="cta-arrow-link--dark-overlay sign-out-margin"  data-ng-click="CommonHeaderCtrl.handleUserSignout()">Sign out</a>
                </div>
                <!--end of logged in-->

            </div>
        </div>
    </div>
</div>

<div class="hbeam-inline global-nav-secondary__item">
    <div class="global-nav-secondary__label">

        <a class="block-link" data-ng-click="CommonHeaderCtrl.handleMenuSelect('pay-bill')" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('pay-bill')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('pay-bill')" class="global-header__link" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('pay-bill')}">Pay bill</a>

        <div class="header-dropmenu paybill-menu" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('pay-bill')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('pay-bill')" data-ng-show="CommonHeaderCtrl.isActiveMenu('pay-bill')">

            <div class="menu-top" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession">
                <!--logged in-->
                <div ng-cloak>
                    <!-- IF BILL DUE-->
                    <section class="paybill-info">
                        <div data-ng-show="!bpGlobalError && !isunAuthorized">
                            <span class="xsfont color-secondary-darken">Amount due</span>
                            <div class="margin-top-1" data-ng-show="!(negativeBalance || zeroBalance)">
                                <span class="xlfont"><strong data-ng-cloak>{{currency(dueAmount)}}</strong></span>
                            </div>
                            <div class="margin-top-1" data-ng-show="negativeBalance || zeroBalance">
                                <span class="xlfont"><strong data-ng-cloak>$0</strong></span>
                            </div>
                                    <div class="margin-top-1" data-ng-show="dueDays > 1 && !(negativeBalance || zeroBalance)">
                                        <span class="lfont">due in {{dueDays}} days</span>
                                    </div>
                                    <div class="margin-top-1" data-ng-show="dueDays == 1 && !(negativeBalance || zeroBalance)">
                                        <span class="lfont">due in {{dueDays}} day</span>
                                    </div>
                                    <div class="margin-top-1" data-ng-show="dueDays == 0 && !(negativeBalance || zeroBalance)">
                                        <span class="lfont">due today</span>
                                    </div>

                                    <div class="margin-top-2"  data-ng-show="!(negativeBalance || zeroBalance || pastDueAvailable)">
                                        <span class="sfont color-secondary-darken">{{dueDate}}</span>
                                    </div>

                            <!-- POSITIVE BALANCE -->
                            <div data-ng-show="positiveBalance">
                                <div data-ng-show="pastDueAvailable">
                                    <br>
                                    <div class="blocked-container">
                                        <div class="blocked-image margin-top-1">
                                            <span class="dot dot--dark-overlay alert-background">
                                            <span class="dot-inner"><i
                                                class="icon-exclamation-major"></i> </span>
                                            </span>
                                        </div>
                                        <div class="blocked-text xsfont">
                                            <div class="margin-top-1">
                                                <span >{{currency(pastDue)}} past due</span>
                                            </div>
                                            <div>
                                                <span >Next statement {{nextstmtdate}}</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="payNow">
                                        <a class="btn btn--secondary-accent-text" ng-click = "CommonHeaderCtrl.checkingSession('linkPayment')"><strong> Pay </strong><strong data-ng-cloak>&nbsp;{{getPaymentText()}}</strong> </a>
                                    </div>
                                </div>
                                <div data-ng-show="!pastDueAvailable">


                                    <div data-ng-show="enrolled && scheduledPayAmount && scheduledPayDate && scheduledPayNickname">
                                        <div class="margin-top-1">
                                                               <span class="sfont">We will debit
                                                               {{currency(scheduledPayAmount)}} on</span>                                       </div>
                                        <div class="margin-top-2">
                                            <span class="sFont">{{scheduledPayDate}} from {{scheduledPayNickname}}</span>
                                        </div>
                                    </div>
                                    <div class="payNow" data-ng-show="!enrolled">
                                        <a class="btn btn--secondary-accent-text" ng-click = "CommonHeaderCtrl.checkingSession('linkPayment')" ><strong> Pay </strong><strong data-ng-cloak>&nbsp;{{getPaymentText()}}</strong> </a>
                                    </div>
                                </div>
                            </div>
                            <!-- END OF POSITIVE BALANCE -->
                            <!-- ZERO BALANCE -->
                            <div data-ng-show="zeroBalance">
                                <div class="margin-top-1">
                                    <span class="sfont">Next statement date</span>
                                </div>
                                <div class="margin-top-2">
                                    <span class="sfont">{{nextstmtdate}}</span>
                                </div>
                                <div ng-show="receivedPayAmount && receivedPayDate">
                                <div class="margin-top-1" >
                                    <span class="sfont">Your payment of {{currency(receivedPayAmount)}}</span>
                                </div>
                                <div class="margin-top-2">
                                    <span class="sfont">was received on {{receivedPayDate}}</span>
                                </div>
                                </div>
                            </div>
                            <!-- END OF ZERO BALANCE -->
                            <!-- NEGATIVE BALANCE -->
                            <div data-ng-show="negativeBalance && !hasWriteOff">
                                <div class="margin-top-1">
                                    <span class="sfont">A credit of {{currency(negativeBalanceValue)}} will</span>
                                </div>
                                <div class="margin-top-2">
                                    <span class="sfont">be applied to your</span>
                                </div>
                                <div class="margin-top-2">
                                    <span class="sfont">{{nextstmtdate}} statement</span>
                                </div>
                            </div>
                            <!-- END OF NEGATIVE BALANCE -->
                        </div>
                        <!--LOGGED IN, BUT HAVE NO ACCESS TO PAYBILL-->
                        <div class="no-bill-access" data-ng-show="isunAuthorized">
                            <div>
                                <span class="mfont not-bold">You do not have access</span>
                            </div>
                            <div>
                                <span class="mfont not-bold">to this section.</span>
                            </div>
                            <div class="margin-top-1">
                                <span class="sfont">Please sign in as the primary</span>
                            </div>
                            <div class="margin-top-2">
                                <span class="sfont">Optimum ID to view and pay your bill,</span>
                            </div>
                            <div class="margin-top-2">
                                <span class="sfont">or to grant access to additional users</span>
                            </div>
                        </div>
                        <!--END OF LOGGED IN, BUT HAVE NO ACCESS TO PAYBILL-->
                        <!-- Blocked State -->
                        <div class="blocked-container"
                            data-ng-show="blockedAccount">
                            <div class="blocked-image margin-top-1">
                                <span class="dot dot--dark-overlay alert-background">
                                    <span class="dot-inner"><i
                                        class="icon-exclamation-major"></i> </span>
                                </span>
                            </div>
                            <div class="blocked-text xsfont">
                                <div class="margin-top-1">
                                    <span>Sorry, we can't accept</span>
                                </div>
                                <div class="margin-top-2">
                                    <span>online payments for</span>
                                </div>


                                <div class="margin-top-2">
                                    <span>your account.</span>
                                </div>
                                <div class="margin-top-1">
                                    <span>Contact us at</span>
                                </div>
                                <div class="margin-top-2">
                                    <span>(866) 213-7456 to</span>
                                </div>
                                <div class="margin-top-2">
                                    <span>make a payment.</span>
                                </div>
                            </div>
                        </div>
                        <!--End of Blocked State -->
                        <!-- API Error -->
                        <div class="api-error" data-ng-show="bpGlobalError && !isunAuthorized">
                            <div>
                                <span class="mfont not-bold">Sorry we can't access </span>
                            </div>
                            <div>
                                <span class="mfont not-bold">your billing info right now.</span>
                            </div>
                        </div>
                        <!--END OF API Error -->
                    </section>
                </div>
                <!--end of logged in-->
            </div>
				<!--logged out-->
            <div class="menu-mdl" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession">
                <div>
                    <div>
                        <ul class="margin-top-1">
                            <li><a href="/pay-bill">Pay Online</a></li>
                            <li><a href="/pay-bill/payin-person">Pay in Person</a></li>
                            <li><a href="/FAQ#/answers/a_id/313">Pay by Mail</a></li>
                        </ul>
                    </div>
                </div>
                <!--end of logged out-->
            </div>
            <div class="menu-mdl" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession">
                <!--logged in-->
                <div>
                    <div class="paybill-li" data-ng-show="!isunAuthorized">
                        <ul class="margin-top-1">
                            <li><a href="/pay-bill/my-bill">View my bill</a></li>
                        </ul>
                         <ul data-ng-show="autopayscheduled && !blockedAccount">
                            <li><a ng-click= "CommonHeaderCtrl.checkingSession('linkManage')">Manage payment methods</a></li>
                            <li><a ng-click= "CommonHeaderCtrl.checkingSession('linkAuto')">Manage automatic payments</a></li>
                            <li><a ng-click= "CommonHeaderCtrl.checkingSession('linkPayment')">Make a one-time payment</a></li>
                        </ul>
                        <ul data-ng-show="autopaynoscheduled && !blockedAccount">
                            <li><a ng-click= "CommonHeaderCtrl.checkingSession('linkManage')">Manage payment methods</a></li>
                            <li><a ng-click= "CommonHeaderCtrl.checkingSession('linkAuto')">Manage automatic payments</a></li>
                            <li><a ng-click= "CommonHeaderCtrl.checkingSession('linkPayment')">Make a one-time payment</a></li>
                        </ul>
                        <ul data-ng-show="noautopayscheduled && !blockedAccount">
                            <li><a ng-click= "CommonHeaderCtrl.checkingSession('linkManage')">Manage payment methods</a></li>
                            <li><a ng-click= "CommonHeaderCtrl.checkingSession('linkAuto')">Set up automatic payments</a></li>
                            <li><a ng-click= "CommonHeaderCtrl.checkingSession('linkPayment')">Make a one-time payment</a></li>
                        </ul>
                        <ul data-ng-show="noautopaynoscheduled && !blockedAccount">
                            <li><a ng-click= "CommonHeaderCtrl.checkingSession('linkManage')">Manage payment methods</a></li>
                            <li><a ng-click= "CommonHeaderCtrl.checkingSession('linkAuto')">Set up automatic payments</a></li>
                            <li><a ng-click= "CommonHeaderCtrl.checkingSession('linkPayment')">Make a one-time payment</a></li>
                        </ul>

                        <ul class="margin-top-1">
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkAccount')">Account activity</a></li>
                        </ul>
                        <ul class="margin-top-1">
                            <li><a href="/support/pay-bill">Billing support</a></li>
                            <esi:include src="/services/cms-menu?path=pay-bill" />
                        </ul>
                    </div>
                    <!--end of logged in-->
                    <!--LOGGED IN, BUT HAVE NO ACCESS TO PAYBILL-->

                    <div data-ng-show="isunAuthorized">
                    <p class="signout-text">Not {{CommonHeaderCtrl.currentLoggedInUser.optimumId}}?</p> <a cta-arrow-link class="cta-arrow-link--dark-overlay sign-out-margin"  data-ng-click="CommonHeaderCtrl.handleUserSignout()">Sign out</a>
                    </div>


                    <!--<div data-ng-show="isunAuthorized">
                        <div class="signout">
                            <ul>
                                <li>Not {{CommonHeaderCtrl.currentLoggedInUser.optimumId}}? <a cta-arrow-link class="secondary"  data-ng-click="CommonHeaderCtrl.handleUserSignout()">Sign out</a></li>
                            </ul>
                        </div>
                    </div>-->
                </div>

            </div>
        </div>
    </div>
</div>
<div class="hbeam-inline global-nav-secondary__item">
    <div class="global-nav-secondary__label">

        <a class="block-link" data-ng-click="CommonHeaderCtrl.handleMenuSelect('support')" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('support')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('support')" class="global-header__link" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('support')}">Support</a>

        <div class="support-ddmenu">
            <div class="header-dropmenu header-dropmenu-alignment" data-ng-class="{'header-dropmenuEsp':CommonHeaderCtrl.isEspanolLang}" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('support');CommonHeaderCtrl.initSupportMenu()" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('support')" data-ng-show="CommonHeaderCtrl.isActiveMenu('support')">

                <div class="menu-top">

                    <ul class="support-menu">
                        <li class="user-service-link"  data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession || CommonHeaderCtrl.currentLoggedInUser.hasSession && CommonHeaderCtrl.currentLoggedInUser.hasService.tv">
                            <a href="/support/tv">
								<ul>
									<li class="service-icon">
										<i class="support-icons tv-icon"></i>
									</li>
									<li class="service-name">TV</li>
								</ul>
							</a>
                        </li>
                        <li class="user-service-link" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession || CommonHeaderCtrl.currentLoggedInUser.hasSession && CommonHeaderCtrl.currentLoggedInUser.hasService.phone">
                            <a href="/support/phone">
								<ul>
									<li class="service-icon">
										<i class="support-icons phone-icon"></i>
									</li>
									<li class="service-name">Phone</li>
								</ul>
							</a>
                        </li>
                        <li class="user-service-link" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession || CommonHeaderCtrl.currentLoggedInUser.hasSession && CommonHeaderCtrl.currentLoggedInUser.hasService.internet">
                            <a href="/internet?from=support">
								<ul>
									<li class="service-icon">
										<i class="support-icons internet-icon"></i>
									</li>
									<li class="service-name">Internet</li>
								</ul>
							</a>
                        </li>
                        <li class="user-service-link">
                            <a href="/support/pay-bill">
								<ul>
									<li class="service-icon">
										<i class="support-icons paybill-icon"></i>
									</li>
									<li class="service-name">Billing</li>
								</ul>
							</a>
                        </li>
                    </ul>
                    <!-- chat & outage -->
					<div>
						<!--<div class="span6 support-chat" ng-click="chatNow()">
							<div class="btn btn--secondary-accent-text">
                                <div class="round-circle">
                                    <i class="icon-chat"></i>
                                </div>
                                <h4>Chat now</h4>
							</div>
                        </div>-->
						<div class="span6 support-chat" id="LP_Optimum_Header_Desktop"></div>
                        <div class="span6 support-alert" ng-click="reloadOutageRoute()" style="margin-top: 8px;">
							<div class="btn btn--secondary-accent-text" style="padding-bottom: 0.7rem;">
                                <div class="round-circle">
                                    <i class="icon-selfhelp2"></i>
                                </div>
                                <h4 class="no-btm-mrgn">Check for<br/>outages</h4>
							</div>
                        </div>
					</div>
                </div>
                <div class="menu-mdl">
                    <div class="span5">
                        <ul class="support-lower-links">
                            <esi:include src="/services/cms-menu?path=support-1" />
                        </ul>
                    </div>

                    <div class="span7">
                        <div>
                            <ul class="support-lower-links">
                                <esi:include src="/services/cms-menu?path=support-2" />
                            </ul>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>

    <div class="global-nav-secondary__notification" data-ng-show="CommonHeaderCtrl.currentAlertIndex > 0">

        <a data-ng-click="CommonHeaderCtrl.toggleAlertDrawer()" class="alert-{{CommonHeaderCtrl.currentAlert}} alert-drawer__handle hbeam-inline badge-notification badge-primary">
            <div class="hbeam-part-static badge-notification__icon-container">
                <i class="badge-notification__icon icon-warning-sign"></i>
            </div>
            <div>
                <span class="badge-notification__count">{{CommonHeaderCtrl.currentAlertIndex}}</span>
            </div>
        </a>
    </div>

</div>

<div class="hbeam-inline global-nav-secondary__item">
    <div class="global-nav-secondary__label">

        <div class="yext-search"></div>
    </div>
</div>


</div>
<!-- end global-nav-secondary -->

</div>
<!-- end span8 -->

</div>
</div>
</div>
<div class="row">
<div class="span4">
    <div class="global-header__brand">
        <a href="/" class="desktop-logo"></a>
    </div>
</div>
<div id="mega-menu-container" class="span8 app-header__nav-primary">

<!-- DESKTOP/TABLET: PRIMARY NAV -->
<div class="hflow global-nav-primary">
<div class="hflow global-nav-primary__item block-link" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('internet')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('internet')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('internet')}">
    <div class="global-nav-primary__label">
        <a data-ng-click="CommonHeaderCtrl.handleMenuSelect('internet')" class="global-header__link">
        <span class="mega-menu-cursor global-header__link no-bold">Internet</span>
        </a>
        <div class="internet-menu">
            <div data-ng-class="{'leftMargin-internetMenu-noemail' :!CommonHeaderCtrl.currentLoggedInUser.hasService.musActive , 'leftMargin-internetMenu-less-email' : CommonHeaderCtrl.currentLoggedInUser.hasService.musActive && CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount<=9}" class="header-dropmenu" data-ng-show="CommonHeaderCtrl.isActiveMenu('internet')">

                <div class="menu-mdl">

                    <div class="row internet-links">
                        <div class="span6">
							<ul>
								<esi:include src="/services/cms-menu?path=megamenu-internet-1" />
							</ul>
                        </div>
                        <div class="span6">
							<ul>
								<esi:include src="/services/cms-menu?path=megamenu-internet-2" />
							</ul>
                        </div>
                    </div>
				</div>
                <div class="menu-bottom {{CommonHeaderCtrl.currentLoggedInUser.hasSession}} {{CommonHeaderCtrl.currentLoggedInUser.hasService.musActive}}_mus " ng-hide="CommonHeaderCtrl.ooluser.isWestUser">
                    <!--logged out-->
                    <div data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession">
                        <h4><a href="/login">Sign in</a> to check your email and manage your internet features</h4>
                    </div>
                    <!--end of logged out-->

                    <!--logged in-->
                    <div data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession && CommonHeaderCtrl.currentLoggedInUser.hasService.musActive">
                        <div id="inbox">
                            <div class="row top-row">
                                <div class="span8">
                                    <h4>Email Inbox <button class="btn btn--secondary" data-ng-hide="CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount == -1">{{CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount}}</button></h4>
                                </div>
                                <div class="span4">
                                    <a cta-arrow-link class="cta-arrow-link--dark-overlay pull-right" href="{{CommonHeaderCtrl.webmailLink}}" data-ng-hide="CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount == -1">View all</a>
                                </div>
                            </div>

                            <!--email-->
                            <div data-ng-repeat="email in CommonHeaderCtrl.currentLoggedInUser.inbox.emails" class="email-group {{email.status}}">
                                <div class="row">
                                    <div class="span9">
                                        <h4 class="from">{{email.from}}</h4>
                                    </div>
                                    <div class="span3">
                                        <h5>{{email.date | moment : CommonHeaderCtrl.currentLoggedInUser.inbox.dateFormat}}</h5>
                                    </div>
                                </div>
                                <div class="row" >
                                    <div class="span12">
                                        <span class="subject" ><a href="{{ email.link }}"><u>{{email.subject}}</u></a></span>
                                    </div>
                                </div>
                            </div>
                            <!--end of email-->
                        </div>

                        <p data-ng-show="CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount == -1">We can't get your messages right now. Please try again later.</p>
                        <p data-ng-show="CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount == 0">You have no new emails</p>

                    </div>
                    <!--end of logged in-->

                </div>

            </div>

        </div>

    </div>
    <div class="global-nav-primary__notification">
        <span ng-hide="CommonHeaderCtrl.ooluser.isWestUser">
            <a href="{{CommonHeaderCtrl.webmailLink}}" class="hbeam-inline badge-notification badge-primary"
            data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession || (CommonHeaderCtrl.currentLoggedInUser.hasSession && CommonHeaderCtrl.currentLoggedInUser.hasService.musActive)">
                <div class="hbeam-part-static badge-notification__icon-container" data-ng-class="{'logged-out-envelope-container' : !CommonHeaderCtrl.currentLoggedInUser.hasSession}">
                    <i class="badge-notification__icon icon-envelope-alt" data-ng-class="{'logged-out-envelope icon-large': !CommonHeaderCtrl.currentLoggedInUser.hasSession}"></i>
                </div>
                <div>
                    <span data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession && CommonHeaderCtrl.currentLoggedInUser.hasService.musActive && CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount >= 0" class="badge-notification__count">{{CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount}}</span>
                </div>
            </a>
        </span>
        <span ng-show="CommonHeaderCtrl.ooluser.isWestUser && CommonHeaderCtrl.emailAddr">
            <a href="{{CommonHeaderCtrl.webmailLink}}" class="hbeam-inline badge-notification badge-primary"
            data-ng-show="(!CommonHeaderCtrl.currentLoggedInUser.hasSession && CommonHeaderCtrl.ooluser.isWestUser) || (CommonHeaderCtrl.currentLoggedInUser.hasSession && CommonHeaderCtrl.currentLoggedInUser.hasService.musActive)">
                <div class="hbeam-part-static badge-notification__icon-container logged-out-envelope-container">
                    <i class="badge-notification__icon icon-envelope-alt logged-out-envelope icon-large"></i>
                </div>
            </a>
        </span>
    </div>
</div>
<div class="hflow global-nav-primary__item block-link" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('tv')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('tv')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('tv')}">
    <div class="global-nav-primary__label">
        <a data-ng-click="CommonHeaderCtrl.handleMenuSelect('tv')" class="global-header__link" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('tv')}">
        <span class="mega-menu-cursor global-header__link" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('tv')}">TV</span>
        </a>
        <div class="tv-menu" ng-class="{'tv-dvr-menu': CommonHeaderCtrl.currentLoggedInUser.hasService.dvr}">
            <div class="header-dropmenu" data-ng-show="CommonHeaderCtrl.isActiveMenu('tv')">

                <div class="menu-mdl">

                    <div class="row tv-links">
                        <div class="span6">
                            <h4 class="cHShift">Watch</h4>
                            <ul>
                                <esi:include src="/services/cms-menu?path=megamenu-tv-watch" />
                            </ul>
                        </div>
                        <div class="span6">
                            <h4>Features & settings</h4>
                            <ul>
                                <esi:include src="/services/cms-menu?path=megamenu-tv-features" />
                            </ul>
                        </div>
                    </div>

                </div>
                <div class="menu-bottom" ng-hide="(!CommonHeaderCtrl.labox && CommonHeaderCtrl.isWestUser)">

                    <!--logged out-->
                    <div data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession">
                        <h4><a href="/login">Sign in</a> to manage your DVR and TV features.</h4>
                    </div>
                    <!--end of logged out-->

                    <!--logged in-->
                    <div id="dvr" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession">
                        <div class="row" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasService.dvr">
                            <div class="span4">
                                <h4>My DVR</h4>
                            </div>
                            <div class="span8">
                                <a cta-arrow-link class="cta-arrow-link--dark-overlay pull-right" href="/tv/dvr/#/scheduled" class="pull-right">View recordings</a>
                            </div>
                        </div>
                        <div class="row">

                            <!-- DVR, Scheduled Recordings -->
                            <div class="span12 dvr-recordings" data-ng-class="{active: CommonHeaderCtrl.currentLoggedInUser.hasService.dvr}">

                                <h4 data-ng-show="CommonHeaderCtrl.dvrMenu.alertNoScheduled">
                                    You have no recordings scheduled.</h4>

                                <!-- dvr-recordings, bottom row -->
                                <div class="row dvr-recordings-bottom">
                                    <div class="span12">

                                        <h4 data-ng-show="CommonHeaderCtrl.dvrMenu.alertNoService">
                                            Service unavailable at this time.
                                        </h4>

                                        <h4 class="learnmore" data-ng-show="(!CommonHeaderCtrl.currentLoggedInUser.hasService.dvr)">
                                            <a href="/FAQ#/answers/a_id/2580">Click here</a> to learn more about DVR</h4>

                                        <div id="dvr-spinner" class="spin-restraint" data-ng-show="CommonHeaderCtrl.loadingScheduledRecordings && !CommonHeaderCtrl.dvrMenu.alertNoService && !CommonHeaderCtrl.dvrMenu.alertNoScheduled">
                                            <spinner color="'#fff'" data-length="12" data-radius="12"></spinner>
                                        </div>
                                        <ul>
                                            <li data-ng-repeat="recording in CommonHeaderCtrl.dvrMenu.nextThreeRecordings" class="poster poster--s">
                                                <a href="{{recording.href}}">
                                                    <poster class="poster--s" label="{{recording.title}}" url="{{recording.thumb}}"></poster>
                                                    <!--<img alt="thumbnail" data-ng-src="{{recording.thumb}}">-->
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- /dvr-recordings, bottom row -->

                            </div>
                        </div>
                    </div>
                    <!--end of logged in-->

                </div>

            </div>
        </div>




    </div>
    <div data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasService.dvr && !CommonHeaderCtrl.isHideDvr" class="global-nav-primary__notification">
        <a href="/tv/dvr" class="hbeam-inline badge-notification badge-primary">
            <div>
                <span class="badge-notification__count">DVR</span>
            </div>
        </a>
    </div>
</div>

<div class="hflow global-nav-primary__item block-link" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('phone')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('phone')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('phone')}">
    <div class="global-nav-primary__label">
        <a data-ng-click="CommonHeaderCtrl.handleMenuSelect('phone')" class="global-header__link">
        <span class="mega-menu-cursor global-header__link">Phone</span>
        </a>
        <div class="phone-menu" ng-class="{'nophone-menu': (CommonHeaderCtrl.currentLoggedInUser.hasSession && !CommonHeaderCtrl.currentLoggedInUser.hasService.phone)}">
            <div data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession">
                <div data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasService.phone" >
                    <div>
                        <div class="header-dropmenu" data-ng-show="CommonHeaderCtrl.isActiveMenu('phone')">
                            <div class="menu-mdl">
                                <div class="row phone-links">
                                    <div class="span6">
                                        <ul id="cms_content_phone">
                                            <esi:include src="/services/cms-menu?path=megamenu-phone-1" />
                                        </ul>
                                    </div>
                                    <div class="span6">
                                        <ul>
                                            <esi:include src="/services/cms-menu?path=megamenu-phone-2" />
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasService.phone" >
                    <div class="header-dropmenu" data-ng-show="CommonHeaderCtrl.isActiveMenu('phone')">
                        <div class="menu-mdl">
                            <div class="row phone-links">
                                <div class="span6">
                                    <ul id="cms_content_phone">
                                        <esi:include src="/services/cms-menu?path=megamenu-phone-1" />
                                    </ul>
                                </div>
                                <div class="span6">
                                    <ul>
                                        <esi:include src="/services/cms-menu?path=megamenu-phone-2" />
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="menu-bottom">
                            <!--MY MESSAGES-->
                            <div class="row">
                                <div class="span7">
                                    <h4>My Messages <button data-ng-click="{{CommonHeaderCtrl.basePhoneMenuUrl}}/Voicemail" class="btn btn--secondary">{{CommonHeaderCtrl.currentLoggedInUser.phone.count}}</button></h4>
                                </div>
                                <div class="span5">
                                    <a cta-arrow-link class="cta-arrow-link--dark-overlay pull-right" href="{{CommonHeaderCtrl.basePhoneMenuUrl}}/Voicemail">View all</a>
                                </div>
                            </div>
                            <div class="row" data-ng-repeat="message in CommonHeaderCtrl.currentLoggedInUser.phone.messages">
                                <div class="span5">
                                    <span>{{message.number}}</span>
                                </div>
                                <div class="span7">
                                    <span>{{message.time}}</span>
                                </div>
                                <br/>
                            </div>
                            <!--end of MY MESSAGES-->
                        </div>
                    </div>
                </div>
            </div>

            <div data-ng-hide="CommonHeaderCtrl.currentLoggedInUser.hasSession">
                <div class="header-dropmenu" data-ng-show="CommonHeaderCtrl.isActiveMenu('phone')">
                    <div class="menu-top">
                        <div class="row phone-links">
                            <div class="span6">
                                <ul id="cms_content_phone">
                                    <esi:include src="/services/cms-menu?path=megamenu-phone-1" />
                                </ul>
                            </div>
                            <div class="span6">
                                <ul>
                                    <esi:include src="/services/cms-menu?path=megamenu-phone-2" />
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="menu-bottom">
                        <div data-ng-hide="CommonHeaderCtrl.currentLoggedInUser.hasSession">
                            <h4><a href="/login">Sign in</a> to check your messages and manage your phone features</h4>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>


    <div data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession && !CommonHeaderCtrl.currentLoggedInUser.hasService.phone" class="global-nav-primary__notification">
        <div class="global-nav-primary__notification">
          <a href="{{CommonHeaderCtrl.basePhoneMenuUrl}}/Voicemail" class="hbeam-inline badge-notification badge-primary">
            <div class="hbeam-part-static badge-notification__icon-container morePadding">
                <i class="badge-notification__icon icon-phone moreWidth"></i>
            </div>
          </a>
        </div>
    </div>

    <div data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession && CommonHeaderCtrl.currentLoggedInUser.hasService.phone" class="global-nav-primary__notification">
        <a href="{{CommonHeaderCtrl.basePhoneMenuUrl}}/Voicemail" class="hbeam-inline badge-notification badge-primary">
            <div class="hbeam-part-static badge-notification__icon-container">
                <i class="badge-notification__icon icon-phone"></i>
            </div>
            <div>
                <span class="badge-notification__count">{{CommonHeaderCtrl.currentLoggedInUser.phone.count}}</span>
            </div>
        </a>
    </div>

</div>

<div class="hflow global-nav-primary__item block-link no--dropdown" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('my-offers')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('my-offers')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('my-offers')}">
    <div class="global-nav-primary__label">
        <a href="/upgrades" class="global-header__link" omtr="trackme" title="Upgrades Menu">
        <span class="mega-menu-cursor global-header__link">My Offers</span>
        </a>
    </div>
</div>



</div>
</div>
<!-- end global-nav-primary -->

</div>
</div>
</div>
</div>
</div>
</section>
<!-- <div id="search_auto_phone" class="auto_complete_phone hidden-desktop hidden" ng-show="CommonHeaderCtrl.showingMobileSearchBar" ng-cloak ng-class="CommonHeaderCtrl.switchStyles()">
    <div class="container phone_auto_complete_background" ng-show="CommonHeaderCtrl.showingMobileSearchBar && CommonHeaderCtrl.searchTerm.length >0 && inputFocus">
    <div class="powered-By-text">Suggestions powered by Optimum</div>
        <div>
            <span class="search_heading">Optimum.net</span>
            <div class="result_container">
                <ul>
                    <li data-ng-click="CommonHeaderCtrl.phoneSearchThis(result.searchQuery,CommonHeaderCtrl.searchCategory.support)"  data-ng-repeat="result in CommonHeaderCtrl.gsaResult.results" ng-class="{ 'border-result-item-bottom': $last}">
                        <span data-ng-bind-html="CommonHeaderCtrl.truncateText(result.text,28)"></span>
                    </li>
                    <li data-ng-show="CommonHeaderCtrl.gsaSuggestionFailed"
                        data-ng-click="CommonHeaderCtrl.supportNavReqd = true;CommonHeaderCtrl.phoneGoToSearch(CommonHeaderCtrl.searchCategory.support)">
                        <span class="searchKey">
                        Search full site for <b>"{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</b>
                        </span>
                    </li>
                    <li data-ng-show="CommonHeaderCtrl.loadingGsa">  Loading... <br></li>
                </ul>
            </div>
        </div>
        <div class="marginTop1rem">
            <span class="search_heading">TV & On Demand</span>
            <div class="result_container">
                <ul>
                    <li data-ng-click="CommonHeaderCtrl.phoneSearchThis(result.searchQuery,CommonHeaderCtrl.searchCategory.faqSearch)"  data-ng-repeat="result in CommonHeaderCtrl.veveoResult.results" ng-class="{ 'border-result-item-bottom': $last}">
                        <span data-ng-bind-html="CommonHeaderCtrl.truncateText(result.text,28)"></span>
                    </li>
                    <li data-ng-show="CommonHeaderCtrl.veveoSuggestionFailed">
                        <span>
                        <b>No result found for "{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</b>
                        </span>
                    </li>
                    <li data-ng-show="CommonHeaderCtrl.loadingVeveo">  Loading... <br></li>
                </ul>
            </div>
        </div>
        <div class="marginTop1rem">
            <span class="search_heading google-heading">Web results</span>
            <span class="google-logo fixedpos"></span>
            <div class="result_container">
                <ul>
                    <li data-ng-click="CommonHeaderCtrl.phoneSearchThis(result.searchQuery,CommonHeaderCtrl.searchCategory.google)"  data-ng-repeat="result in CommonHeaderCtrl.googleResult.results" ng-class="{ 'border-result-item-bottom': $last}">
                        <span data-ng-bind-html="CommonHeaderCtrl.truncateText(result.text,28)"></span>
                    </li>
                    <li data-ng-show="CommonHeaderCtrl.googleSuggestionFailed"
                        data-ng-click="CommonHeaderCtrl.phoneGoToSearch(CommonHeaderCtrl.searchCategory.google)">
                        <span>
                        <b>Search the web for "{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</b>
                        </span>
                    </li>
                    <li data-ng-show="CommonHeaderCtrl.loadingGoogle">  Loading... <br></li>
                </ul>
            </div>
        </div>
        <div class="marginTop1rem">
            <span class="search_heading">Keep searching</span>
            <div class="result_container">
                <ul>
                    <li data-ng-click="CommonHeaderCtrl.supportNavReqd = true;CommonHeaderCtrl.phoneGoToSearch(CommonHeaderCtrl.searchCategory.support)">
                        <span>Search full site for "{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</span>
                    </li>
                    <li data-ng-click="CommonHeaderCtrl.phoneGoToSearch(CommonHeaderCtrl.searchCategory.faqSearch)">
                        <span>Search TV & On Demand for "{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</span>
                    </li>
                    <li data-ng-click="CommonHeaderCtrl.phoneGoToSearch(CommonHeaderCtrl.searchCategory.google)" class="border-result-item-bottom">
                        <span>Search the web for "{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</span>
                    </li>
                </ul>
            </div>
        </div>
        <br>
    </div>
</div>
 -->
    <!-- IE8/depcreated browser and Compat Mode alert messages -->
    <section id="dep-browser-banner" data-ng-show="CommonHeaderCtrl.showDeprecatedBrowserBanner" class="hidden-phone hidden-tablet theme-primary">
        <div class="row">
            <div class="container">
                <div class="span12">
                    <div class="alert-banner padding-s panel semflex full-width theme-secondary">
                        <div class="ab__icon semflex__auto" data-ng-click="CommonHeaderCtrl.closeDeprecatedBrowserBanner()">
                            <span id="exc-icon" class="pointer dot dot--dark-overlay"><i class="icon-warning-sign"></i></span>
                        </div>
                        <div id="dep-browser-content" class="row" data-ng-show="CommonHeaderCtrl.showDeprecatedBrowserMsg">
                            <div id="message" class="ab__text text-unspace span9">
                                <h4 id="title">We've detected that you're using an older version of {{CommonHeaderCtrl.deprecatedBrowserName}}</h4>
                                <p class="mmessage__message">Optimum.net is compatible with a wide range of browsers. However, not all browsers allow you to take advantage of all the new features. We strongly recommend that you upgrade to a more current browser.</p>
                            </div>
                            <div id="browser-icons" class="span3">
                                <a ng-show="CommonHeaderCtrl.showIEBrowserIcon" href="http://windows.microsoft.com/ie"><img ng-src="{{imageBaseURL}}/logo_ie.png" alt="goto Internet Explorer download"/></a>
                                <a href="https://www.google.com/intl/en/chrome/browser"><img ng-src="{{imageBaseURL}}/logo_chrome.png" alt="goto Chrome download"/></a>
                                <a href="http://www.mozilla.org/en-US/firefox/new"><img ng-src="{{imageBaseURL}}/logo_firefox.png" alt="goto Firefox download"/></a>
                            </div>
                        </div>
                        <div id="compat-mode-content" class="row" data-ng-show="CommonHeaderCtrl.showCompatModeMsg">
                            <div class="ab__text text-unspace span12">
                                <h4 class="title">You need to change your Internet Explorer Compatibility View setting to get the most from the new Optimum.net</h4>
                                <p class="mmessage__message">Click <a href="/FAQ#/answers/a_id/3703">here</a> for more info.</p>
                            </div>
                        </div>
                        <div class="ab__icon semflex__auto" data-ng-click="CommonHeaderCtrl.closeDeprecatedBrowserBanner()">
                            <span class="pointer"><i class="icon-remove"></i></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <input type="hidden" id="selenium-header-marker" value="{{seleniumMarker}}"/>
</div>

<div id="is-cpc-header-wrapper" ng-cloak class="hide">
<section id="common-header"  data-ng-class="{true: 'logged-in', false: 'logged-out'}[CommonHeaderCtrl.currentLoggedInUser.hasSession]">
<div class="visible-phone visible-tablet global-header" >
<div class="container">
<div id="phone_header" class="semflex full-width align-children-middle">
        <div class="cpcpadding-s global-header-phone__brand">
            <a href="/" class="block mobile-logo"></a>
         </div>
        </div>
        </div>
        </div>
        <div sticky-stack class="global-header hidden-phone sticky-stack-pseudo" id="desktop_header" >
        <div style="min-width:1000px" id="desktop_header">
        <div class="container">
        <div class="toggle-container">
        <div class="span4">
         <div class="global-header__brand">
         <a href="/" class="desktop-logo"></a>
         </div>
         </div>
</div>
</div>
</div>
</div>
</section>
</div>
<div id="is-newCustomer-header-wrapper" ng-cloak class="hideForNewCustomerStuff hidden-desktop hidden-phone">
<section id="common-header-newCustomer"  data-ng-class="{true: 'logged-in', false: 'logged-out'}[CommonHeaderCtrl.currentLoggedInUser.hasSession]">
        <div class="global-header sticky-stack-pseudo" id="newCustomer-ipad">
        <div id="desktop_header_NewCustomer-ipad">
        <div class="container">
        <div class="toggle-container">
         <div class="global-header__brand">
         <a href="/" class="desktop-logo"></a>
         </div>
</div>
</div>
</div>
</div>
</section>
</div>
<section class="missing-page">
	<div id="header">
		<div class="container">
			<div class="row">
				<div class="span12">
					<h1 class="theme--primary">Sorry, the page you requested could not be found</h1>
				</div>
			</div>
		</div>
	</div>
	<div id="missing-content">
		<div class="container">
			<div class="row">
				<div class="span12">
					<ul>
						<li><p>We apologize for any inconvenience</p></li>
						<li><p>Go to the <a href="/">Optimum.net</a> home page</p></li>
						<li><p>Click <a ng-click="actions.back();">here</a> to return to the previous page</p></li>
						<li><p><span id="LP_Optimum_404_Desktop"></span> for more assistance</p></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="common-footer-help" data-ng-controller="CommonFooterCtrl" id="is-not-cpc-common-footer-help">
	<div class="container" >
		<div class="row">
				<ul id="contact-list">
					<li class="span4"><span id="LP_Optimum_ContactUS_Footer_Desktop"></span></li>
					<!--<li class="span3"><a href="/support/contact-us/"><span class="txt"><i class="icon-feedback" data-hover-class="icon-feedback-hover"></i>Give us feedback</span></a></li>-->
					<li class="span4" ng-class="{true: 'second-last'}[isDeviceWidth.phone == false]">
						<a class="no-left" href="{{CommonFooterCtrl.twitterLink}}">
							<span class="txt"><i class="icon-opthelp" data-hover-class="icon-opthelp-hover"></i>@OptimumHelp</span>
						</a>
					</li>
					<li class="span4"><a class="no-left" href="https://www.optimum.com/stores"><span class="txt" ng-class="{true: 'help-last'}[isDeviceWidth.phone == false]"><i class="icon-optstore" data-hover-class="icon-optstore-hover"></i>Optimum Stores</span></a></li>
				</ul>
				<div class="hidden-desktop hidden-tablet">&nbsp;</div>
		</div>
	 </div>
</section>
<section class="common-footer-links" data-ng-controller="CommonFooterCtrl">
	<div class="container minHeightFooter">
		<div class="row">
			<div class="span12" id="is-not-cpc-hr">
				<hr>
			</div>
			<div class="span4 hidden-desktop hidden-tablet" id="is-not-cpc-footer-social-icon">
				<ul>
				<li class="footer-social-icon">
					<a class="footer-logo-facebook" href="https://www.facebook.com/Optimum/"></a>
					</li>
					<li class="footer-social-icon">
					<a class="footer-logo-twitter" href="https://twitter.com/optimum/"></a>
					</li>
					<li class="footer-social-icon">
					<a class="footer-logo-instagram" href="https://instagram.com/optimum/"></a>
					</li>
					<li class="footer-social-icon">
					<a class="footer-logo-youtube" href="https://www.youtube.com/Optimum"></a>
					</li>
				</ul>
			</div>
			<!-- Site Visitors Start -->
			<div ng-show="!showForNewCustomer" class="span9" id="is-not-cpc-footer-site-links">
				<div class="hidden-phone">
					<ul class="footer-site-links">
						<li><a href="/pages/ReportAbuse.html">Report Abuse</a><span class="footer-link-seperator">|</span></li>
						<li><a href="https://www.optimum.com/accessibility">Accessibility</a> <span class="footer-link-seperator">|</span></li>
						<li><a href="/pages/storm-preparedness.html">Storm Preparedness</a> <span class="footer-link-seperator">|</span></li>
						<li><a href="https://www.optimum.com/terms-of-service/Legal-Compliance" target="_blank">Legal Compliance</a></li>
					</ul>
					<ul class="footer-site-links">
						<li><a href="https://www.optimum.com/terms-of-service">Service Terms & Info</a> <span class="footer-link-seperator">|</span></li>
						<li><a href="https://www.optimum.com/terms-of-service/Copyright-Policy" target="_blank">Copyright Policy</a> <span class="footer-link-seperator">|</span></li>
						<li><a href="https://www.optimum.com/terms-of-service/privacy/Customer-Privacy" target="_blank">Privacy Notice</a> <span class="footer-link-seperator">|</span></li> 
						<li><a href="https://alticeusa.com" target="_blank">About Altice USA</a></li>
					</ul>
				</div>

				<div class="row margin-footer-link hidden-desktop hidden-tablet layout-mobile">
					<div style="float:left; width:42%;">
						<ul class="footer-site-links-mob">
							<li><a href="/pages/ReportAbuse.html">Report Abuse</a></li>
							<li><a href="https://www.optimum.com/accessibility">Accessibility</a></li>
							<li><a href="/pages/storm-preparedness.html">Storm Preparedness</a></li>
							<li><a href="https://www.optimum.com/terms-of-service/Legal-Compliance" target="_blank">Legal Compliance</a></li>
						</ul>
					</div>

					<div style="float:left; width:42%;">
						<ul class="footer-site-links-mob">
							<li><a href="https://www.optimum.com/terms-of-service">Service Terms & Info</a></li>
							<li><a href="https://www.optimum.com/terms-of-service/Copyright-Policy" target="_blank">Copyright Policy</a></li>
							<li><a href="https://www.optimum.com/terms-of-service/privacy/Customer-Privacy" target="_blank">Privacy Notice</a></li>
							<li><a href="https://alticeusa.com" target="_blank">About Altice USA</a></li>
						</ul>
					</div>
				</div>
			</div>
			<!-- End Site visitors -->

			<div class="span6 hide" id="is-cpc-footer-site-links">
				<ul class="footer-site-links">
					<li><a href="https://www.optimum.com/terms-of-service" target="_blank">Service Terms & Info</a></li>
					<li><a href="https://www.optimum.com/terms-of-service/Copyright-Policy" target="_blank">Copyright policy</a></li>
					<li><a href="/pages/PrivacyExisting.html" target="_blank">Privacy policy</a></li>
					<li><a href="https://www.optimum.com/terms-of-service/Legal-Compliance" target="_blank">Legal Compliance</a></li>
				</ul>
			</div>
			<div class="span3 hidden-phone" id="is-not-cpc-footer-social-icon-phone" >
				<ul class="fltright">
					<li class="footer-social-icon">
					<a class="footer-logo-facebook" href="https://www.facebook.com/Optimum/"></a>
					</li>
					<li class="footer-social-icon">
					<a class="footer-logo-twitter" href="https://twitter.com/optimum/"></a>
					</li>

					<li class="footer-social-icon">
					<a class="footer-logo-instagram" href="https://instagram.com/optimum/"></a>
					</li>
					<li class="footer-social-icon">
					<a class="footer-logo-youtube" href="https://www.youtube.com/Optimum"></a>
					</li>
				</ul>
			</div>
		</div>
		<div ng-show="showForNewCustomer" class="row paddingTop1em hidden-phone">
			<div class="span3 ipadWidth34">
				<ul>
					<li class="wide">&copy; Copyright {{CommonFooterCtrl.fullYear}}&nbsp; CSC Holdings, LLC.</li>
				</ul>
			</div>
			<div ng-show="showForNewCustomer" id="new-customer-links"class="span9 opacityfour ipadWidth65">
				<ul class="footer-site-links">
					<li><a href="https://www.optimum.com/terms-of-service" target="_blank">Service Terms & Info</a></li>
					<li><a href="https://www.optimum.com/terms-of-service/Copyright-Policy" target="_blank">Copyright Policy</a></li>
					<li><a href="https://www.optimum.com/terms-of-service/privacy/Customer-Privacy" target="_blank">Privacy Notice</a></li>
					<li><a href="https://www.optimum.com/terms-of-service/Legal-Compliance" target="_blank">Legal Compliance</a></li>
					<li><a href="https://alticeusa.com" target="_blank">About Altice USA</a></li>
				</ul>
			</div>
		</div>
		<div ng-show="showForNewCustomer" class="row paddingTop1em hidden-desktop hideInDesktop hidden-tablet" >
			<div class="span3">
				<ul>
					<li class="marginTopMobile5"><a href="https://www.optimum.com/terms-of-service" target="_blank">Service Terms & Info</a></li>
					<li class="marginTopMobile5"><a href="https://www.optimum.com/terms-of-service/Copyright-Policy" target="_blank">Copyright Policy</a></li>
					<li class="marginTopMobile12"><a href="https://www.optimum.com/terms-of-service/privacy/Customer-Privacy" target="_blank">Privacy Notice</a></li>
					<li><a href="https://www.optimum.com/terms-of-service/Legal-Compliance" target="_blank">Legal Compliance</a></li>
					<li><a href="https://alticeusa.com" target="_blank">About Altice USA</a></li>
				</ul>
			</div>
			<div ng-show="showForNewCustomer" id="new-customer-links"class="span6 opacitypointfour">
				<ul class="footer-site-links">
					<li class="wide">&copy; Copyright {{CommonFooterCtrl.fullYear}}&nbsp; CSC Holdings, LLC.</li>
				</ul>
			</div>
		</div>
		<div ng-show="!showForNewCustomer" class="row" id="is-not-cpc-icon-logo">
			<div class="span10 partner-icons">
				<ul class="hidden-phone">
					<li class="wide hidden-phone">&copy; Copyright {{CommonFooterCtrl.fullYear}}&nbsp;CSC Holdings, LLC.</li>
				</ul>
			</div>
		</div>
		<div style="clear:both">&nbsp;</div>
		<!-- {true:'margin-top-unsuccessful-date'}[statement.status== 'F']-->
		<div class="hidden-desktop hidden-tablet" ng-class="{true:'hidden-desktop hidden-tablet hidden-phone'}[showForNewCustomer==true]">
				<ul>
					<li>
						&copy; Copyright {{CommonFooterCtrl.fullYear}}&nbsp;CSC Holdings, LLC.
					</li>
				</ul>
		</div>
		<div class="row hide " id="is-cpc-icon-logo">
			<div class="span10">
				<ul>
					<li class="is-cpc-wide">&copy; Copyright {{CommonFooterCtrl.fullYear}}&nbsp; CSC Holdings, LLC.</li>
				</ul>
			</div>
		</div>
	</div>
</section>

    </div> <!-- end site-wrapper  -->

    <!-- Make sure to make any changes added here in pages/tv/guide/bottom-guide.muctache + js -->
    <!-- mobile menu flyout-->
    <div ng-cloak>
      <div class="hidden-desktop" data-ng-controller="BottomDefaultCtrl">
        <div sheet class="mobile_menu_sheet" toggle="BottomDefaultCtrl.showingMobileMenu" animate-toward="right">
        <div class="global-nav-container-phone">
          <div class="primary-menu">
          <ul>
            <li>
            <!-- <a href="{{BottomDefaultCtrl.helloMessage.link}}" data-ng-click="BottomDefaultCtrl.toggleshowSignOut()" class="welcome-message speech-balloon speech-balloon--tip-outwards mobile" ng-class="{active : BottomDefaultCtrl.showSignOut}">
              <div class="speech-balloon__content">
  				<p class="username-msg">{{BottomDefaultCtrl.helloMessage.text}}</p>
  			</div>
              <div class="speech-balloon__tip"></div>
            </a>
  		  <div data-ng-show="BottomDefaultCtrl.hasSession">
  			  <div data-ng-show="BottomDefaultCtrl.showSignOut" class="mobile-username-slide">
  				<ul>
  				  <li>Not {{BottomDefaultCtrl.optimumId}}?<br/> <a cta-arrow-link class="footer-accent" data-ng-click="BottomDefaultCtrl.handleUserSignout()">Sign out</a></li>
  				</ul>
  			  </div>
            </div> -->
            <div class="pull-right speech-bubble-home-container" data-ng-show="BottomDefaultCtrl.hasSession">
                <div class="welcome-message speech-balloon speech-balloon--tip-outwards mobile">
                    <div class="speech-balloon__content row">
						<div class="span5 username-msg-div"><a href="/profile" class="username-msg">{{BottomDefaultCtrl.helloMessage.text}}</a></div>
						<div class="span1 verticalLine"></div>
						<div class="span5 signout-msg-div"><a data-ng-click="BottomDefaultCtrl.handleUserSignout()" class="signout-msg">Sign out</a></div>
					</div>
                    <div class="speech-balloon__tip"></div>
                </div>
            </div>
            </li>
            <li><a href="/internet/">Internet</a>
              <div class="pull-right btn btn--secondary-accent gamma" ng-show="!BottomDefaultCtrl.isWestUser && (!BottomDefaultCtrl.hasSession || BottomDefaultCtrl.hasService.musActive)">
                <a href="{{BottomDefaultCtrl.webmailLink}}">
                  <i class="icon icon-envelope"></i>
                  <span ng-show="BottomDefaultCtrl.badge.internet >= 0">{{BottomDefaultCtrl.badge.internet}}</span>
                </a>
              </div>
              <div class="pull-right btn btn--secondary-accent gamma" ng-show="(BottomDefaultCtrl.isWestUser && BottomDefaultCtrl.emailAddr) && (!BottomDefaultCtrl.hasSession || BottomDefaultCtrl.hasService.musActive)">
                <a href="{{BottomDefaultCtrl.webmailLink}}" ng-show="BottomDefaultCtrl.isWestUser">
                  <i class="icon icon-envelope"></i>
                </a>
              </div>
            </li>
            <li><a href="/tv/">TV</a><div data-ng-show="BottomDefaultCtrl.hasService.tv && !BottomDefaultCtrl.isHideDvr" class="pull-right btn btn--secondary-accent gamma"><a href="/tv/dvr/">DVR</a></div></li>
            <li><a href="{{BottomDefaultCtrl.phoneLink}}">Phone</a>
            <div data-ng-show="BottomDefaultCtrl.hasSession && BottomDefaultCtrl.hasService.phone" class="pull-right btn btn--secondary-accent gamma"><a href="{{BottomDefaultCtrl.phoneLink}}/Voicemail"><i class="icon icon-phone"></i>{{BottomDefaultCtrl.badge.phone}}</a></div>
            <div data-ng-hide="BottomDefaultCtrl.hasSession && BottomDefaultCtrl.hasService.phone" class="pull-right btn btn--secondary-accent gamma"><a href="{{BottomDefaultCtrl.phoneLink}}/Voicemail"><i class="icon icon-phone"></i></a></div>
            </li>
            <li><a href="/upgrades" omtr="trackme" title="Upgrades Menu">My Offers</a></li>
          </ul>
          </div>
          <hr>
          <div class="secondary-menu">
          <ul>
            <li><a href="/profile/">My Profile</a></li>
            <li><a data-ng-click = "BottomDefaultCtrl.forward()">Pay bill</a></li>
            <li><a href="/support/">Support <div data-ng-show="BottomDefaultCtrl.badge.support > 0" class="btn btn--alert pull-right"></a><a href="/support/alerts-and-notifications"><i class="icon-exclamation-major"></i> {{BottomDefaultCtrl.badge.support}}</a></div>
            </li>
             <li><a data-ng-show="BottomDefaultCtrl.hasSession && BottomDefaultCtrl.primary" href="/service-appointments/">Service Appointments</a></li>
            <li>
              <div id="LP_Optimum_Header_Mobile"></div>
            </li>
            <li>
                <a href="{{BottomDefaultCtrl.outageLink}}" class="btn btn--secondary-accent-text support-alert-btn">
                  <div class="mobile-support-alert-icon">
                      <div class="round-circle">
                          <i class="icon-selfhelp2"></i>
                      </div>
                  </div>
                  <div class="support-message">
                    <h4 class="msg-left-txt font-settngs">Check for outages</h4>
                  </div>
                </a>
              </li>
          </ul>
          </div>
          <hr>
          <div class="tertiary-menu">
          <ul>
            <li><a href="/support/contact-us/">Contact us</a></li>
			<li><a mporgnav href="https://espanol.optimum.net"
				onclick="return switchLanguage('es');
				function switchLanguage(lang) {
				MP.SrcUrl=decodeURIComponent('mp_js_orgin_url');
				MP.UrlLang='mp_js_current_lang';MP.init();
				MP.switchLanguage(MP.UrlLang==lang?'en':lang);
				return false;}">En espa&#241;ol</a></li>
          </ul>
          </div>
        </div>
        </div><!--/sheet-->
       <input type="hidden" id="selenium-footer-marker" value="{{seleniumMarker}}"/>
      </div>
    </div>

    <script type="text/javascript">
      var reporting_server = 'opt';
      var reporting_pageName = "404";
      var reporting_channelName = null;
    </script>
    <script type="text/javascript">
      if( typeof omnitureValues  !== "undefined"  &&  omnitureValues !== undefined && omnitureValues !== "undefined" && omnitureValues !== "")
      {
      	if(typeof omnitureValues.omniturePageName !== "undefined" &&  omnitureValues.omniturePageName !== undefined && omnitureValues.omniturePageName !== "undefined")
      	{
      		reporting_pageName = omnitureValues.omniturePageName;
      	}

      	if(typeof omnitureValues.omnitureChannelName !== "undefined" &&  omnitureValues.omnitureChannelName !== undefined && omnitureValues.omnitureChannelName !== "undefined")
      	{
      		reporting_channelName = omnitureValues.omnitureChannelName;
      	}
      }

    </script>

    <!-- application script includes -->
    <script src='/vendor.min.js?202303201419'></script>
    <script src='/main.min.js?202303201419'></script>
    <script src='/404/404.min.js?202303201419'></script>
    <script src='/support/outage/outage.js?202303201419'></script>

    <script type="text/javascript">
      if(typeof reporting !== "undefined"){
        reporting.pageLoad();
      }

      trackHistoryURL();
    </script>

	<script type="text/javascript" id="mpelid" src="https://espanol.optimum.net/mpel/mpel.js"></script>
	<script type="text/javascript" src="https://www.googleadservices.com/pagead/conversion_async.js" charset="utf-8"></script>
	<!--[if !IE]> -->
	<!-- <![endif]-->
  <script type="text/javascript">
    $('#header').css({"background-color":"#e0e0e0","color":"#000000"});
    //$('header').css({"background-color":"#e0e0e0","color":"#000000"});
    $('#header .theme-primary').css({"background-color":"#e0e0e0","color":"#000000"});
    $('.header .theme-primary').css({"background-color":"#e0e0e0","color":"#000000"});
    $('header .theme-primary').css({"background-color":"#e0e0e0","color":"#000000"});
    $('#header .theme--primary').css({"background-color":"#e0e0e0","color":"#000000"});
    $('.header .theme--primary').css({"background-color":"#e0e0e0","color":"#000000"});
    $('header .theme--primary').css({"background-color":"#e0e0e0","color":"#000000"});
  </script>
</body>
</html>
